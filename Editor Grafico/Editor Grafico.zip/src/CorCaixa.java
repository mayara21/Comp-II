
public interface CorCaixa {
	public double getR();
	public double getG();
	public double getB();
}
