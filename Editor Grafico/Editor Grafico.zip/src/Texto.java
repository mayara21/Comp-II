public interface Texto {
    String valor();
}