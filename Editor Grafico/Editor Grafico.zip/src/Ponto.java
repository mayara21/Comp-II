
public class Ponto extends Circulo{

	public Ponto(int x, int y, Cor cor){
		super(x, y, 1, cor);
	}
}
