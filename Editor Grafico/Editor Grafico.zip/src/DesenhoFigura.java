public interface DesenhoFigura {
    void desenhar(Retangulo r);
    void desenhar(Circulo c);
    void desenhar(Triangulo t);
}