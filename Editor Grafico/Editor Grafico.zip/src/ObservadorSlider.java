
public interface ObservadorSlider {
    void mudou(double valor);
}
