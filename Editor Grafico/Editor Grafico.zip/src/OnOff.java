public interface OnOff {
    boolean valor();
}